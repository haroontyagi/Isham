using System;
using System.ComponentModel.DataAnnotations;


namespace Invoicebook.ViewModel
{
    public class ClientListViewModel
    {
        public uint Id { get; set; }

        public string Number { get; set; }
        public string Name { get; set; }
        public decimal Balance { get; set; }
        public decimal PaidToDate { get; set; }
        public string ContactName { get; set; }
        public DateTime? CreatedAt { get; set; }

        public List<UserViewModel> Users { get; set; } = new List<UserViewModel>();

    }
}
