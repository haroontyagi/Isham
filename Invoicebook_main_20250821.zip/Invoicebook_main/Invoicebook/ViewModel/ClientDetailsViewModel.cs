using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Invoicebook.ViewModel
{
    public class ClientDetailsViewModel
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public decimal Balance { get; set; }
        public decimal PaidToDate { get; set; }

        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string CountryName { get; set; } // Optional, string for clarity

        public string ShippingAddress1 { get; set; }
        public string ShippingAddress2 { get; set; }
        public string ShippingCity { get; set; }
        public string ShippingState { get; set; }
        public string ShippingPostalCode { get; set; }
        public string ShippingCountryName { get; set; } // Optional

        public List<ClientContactViewModel> Contacts { get; set; } = new List<ClientContactViewModel>();

        // Add other display-only fields as needed (notes, invoices, etc)
    }
}
