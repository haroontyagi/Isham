using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Invoicebook.ViewModel
{
    public class ClientCreateEditViewModel
    {
        public uint? Id { get; set; }

        [Required(ErrorMessage = "Client Name is required")]
        [Display(Name = "Client Name")]
        public string Name { get; set; } = string.Empty;

        // Client Number can be optional or auto-generated
        [Display(Name = "Client Number")]
        public string? Number { get; set; }

        [Display(Name = "User")]
        public uint? UserId { get; set; }

        // Make these optional if business allows
        [Display(Name = "ID Number")]
        public string? IdNumber { get; set; }

        [Display(Name = "VAT Number")]
        public string? VatNumber { get; set; }

        [Display(Name = "Website")]
        public string? Website { get; set; }

        [Display(Name = "Phone")]
        public string? Phone { get; set; }

        [Display(Name = "Public Notes")]
        public string? PublicNotes { get; set; }

        [Display(Name = "Private Notes")]
        public string? PrivateNotes { get; set; }

        [Display(Name = "Size")]
        public uint? SizeId { get; set; }

        [Display(Name = "Industry")]
        public uint? IndustryId { get; set; }

        // Billing Address - mark required if needed, otherwise optional
        [Display(Name = "Street")]
        public string? Address1 { get; set; }

        [Display(Name = "Apt/Suite")]
        public string? Address2 { get; set; }

        public string? City { get; set; }

        public string? State { get; set; }

        [Display(Name = "Postal Code")]
        public string? PostalCode { get; set; }

        [Display(Name = "Country")]
        public uint? CountryId { get; set; }

        // Shipping Address
        [Display(Name = "Shipping Street")]
        public string? ShippingAddress1 { get; set; }

        [Display(Name = "Apt/Suite")]
        public string? ShippingAddress2 { get; set; }

        [Display(Name = "Shipping City")]
        public string? ShippingCity { get; set; }

        [Display(Name = "Shipping State")]
        public string? ShippingState { get; set; }

        [Display(Name = "Shipping Postal Code")]
        public string? ShippingPostalCode { get; set; }

        [Display(Name = "Shipping Country")]
        public uint? ShippingCountryId { get; set; }

        // Contacts
        [Required(ErrorMessage = "At least one contact is required")]

        
        public List<ClientContactViewModel> Contacts { get; set; } = new List<ClientContactViewModel>();

        public SelectList UsersSelectList { get; set; } = new SelectList(Enumerable.Empty<SelectListItem>());


        public List<UserViewModel> Users { get; set; } = new List<UserViewModel>();

    }
}
