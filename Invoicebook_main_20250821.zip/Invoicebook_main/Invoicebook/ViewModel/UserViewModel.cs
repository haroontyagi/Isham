namespace Invoicebook.ViewModel
{

    public class UserViewModel
    {

        public uint Id { get; set; }
        public string Name { get; set; } = string.Empty;
        
    }
}
