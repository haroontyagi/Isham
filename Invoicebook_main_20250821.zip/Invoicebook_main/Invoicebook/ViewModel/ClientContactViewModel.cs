using System.ComponentModel.DataAnnotations;

namespace Invoicebook.ViewModel
{
    public class ClientContactViewModel
    {
        public uint? Id { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Display(Name = "Last Name")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "A valid Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email format")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Phone")]
        public string? Phone { get; set; }
        public List<UserViewModel> Users { get; set; } = new List<UserViewModel>();
        
    }
}
