﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Language
{
    public uint Id { get; set; }

    public string Name { get; set; } = null!;

    public string Locale { get; set; } = null!;
}
