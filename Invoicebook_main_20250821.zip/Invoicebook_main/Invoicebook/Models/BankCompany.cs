﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class BankCompany
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint BankId { get; set; }

    public uint UserId { get; set; }

    public string? Username { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual Bank Bank { get; set; } = null!;

    public virtual ICollection<BankSubcompany> BankSubcompanies { get; set; } = new List<BankSubcompany>();

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
