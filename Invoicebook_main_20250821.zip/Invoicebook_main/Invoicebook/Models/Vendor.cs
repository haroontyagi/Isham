﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Vendor
{
    public uint Id { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public uint? CurrencyId { get; set; }

    public string? Name { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? PostalCode { get; set; }

    public uint? CountryId { get; set; }

    public string? Phone { get; set; }

    public string? PrivateNotes { get; set; }

    public string? Website { get; set; }

    public sbyte IsDeleted { get; set; }

    public string? VatNumber { get; set; }

    public string? TransactionName { get; set; }

    public string? Number { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public string? VendorHash { get; set; }

    public string? PublicNotes { get; set; }

    public string? IdNumber { get; set; }

    public uint? LanguageId { get; set; }

    public DateTime? LastLogin { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual Country? Country { get; set; }

    public virtual Currency? Currency { get; set; }

    public virtual User User { get; set; } = null!;

    public virtual ICollection<VendorContact> VendorContacts { get; set; } = new List<VendorContact>();
}
