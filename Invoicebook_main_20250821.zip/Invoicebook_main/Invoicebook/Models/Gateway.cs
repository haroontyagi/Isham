﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Gateway
{
    public uint Id { get; set; }

    public string Name { get; set; } = null!;

    public string Key { get; set; } = null!;

    public string Provider { get; set; } = null!;

    public bool? Visible { get; set; }

    public uint SortOrder { get; set; }

    public string? SiteUrl { get; set; }

    public bool IsOffsite { get; set; }

    public bool IsSecure { get; set; }

    public string? Fields { get; set; }

    public uint DefaultGatewayTypeId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<CompanyGateway> CompanyGateways { get; set; } = new List<CompanyGateway>();
}
