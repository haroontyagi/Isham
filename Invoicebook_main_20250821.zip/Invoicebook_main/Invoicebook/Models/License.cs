﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class License
{
    public uint Id { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Email { get; set; }

    public string? LicenseKey { get; set; }

    public bool? IsClaimed { get; set; }

    public string? TransactionReference { get; set; }

    public uint? ProductId { get; set; }

    public ulong? RecurringInvoiceId { get; set; }
}
