﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Account
{
    public uint Id { get; set; }

    public string? Plan { get; set; }

    public string? PlanTerm { get; set; }

    public DateOnly? PlanStarted { get; set; }

    public DateOnly? PlanPaid { get; set; }

    public DateOnly? PlanExpires { get; set; }

    public string? UserAgent { get; set; }

    public string? Key { get; set; }

    public uint? PaymentId { get; set; }

    public uint DefaultCompanyId { get; set; }

    public DateOnly? TrialStarted { get; set; }

    public string? TrialPlan { get; set; }

    public decimal? PlanPrice { get; set; }

    public short NumUsers { get; set; }

    public string? UtmSource { get; set; }

    public string? UtmMedium { get; set; }

    public string? UtmCampaign { get; set; }

    public string? UtmTerm { get; set; }

    public string? UtmContent { get; set; }

    public string LatestVersion { get; set; } = null!;

    public bool ReportErrors { get; set; }

    public string? ReferralCode { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool IsSchedulerRunning { get; set; }

    public uint? TrialDuration { get; set; }

    public bool IsOnboarding { get; set; }

    public string? Onboarding { get; set; }

    public bool IsMigrated { get; set; }

    public string? Platform { get; set; }

    public uint? HostedClientCount { get; set; }

    public uint? HostedCompanyCount { get; set; }

    public string? InappTransactionId { get; set; }

    public bool SetReactAsDefaultAp { get; set; }

    public bool IsFlagged { get; set; }

    public bool IsVerifiedAccount { get; set; }

    public string? AccountSmsVerificationCode { get; set; }

    public string? AccountSmsVerificationNumber { get; set; }

    public bool AccountSmsVerified { get; set; }

    public string? BankIntegrationAccountId { get; set; }

    public bool IsTrial { get; set; }

    public virtual ICollection<BankIntegration> BankIntegrations { get; set; } = new List<BankIntegration>();

    public virtual ICollection<Company> Companies { get; set; } = new List<Company>();

    public virtual ICollection<CompanyToken> CompanyTokens { get; set; } = new List<CompanyToken>();

    public virtual ICollection<CompanyUser> CompanyUsers { get; set; } = new List<CompanyUser>();

    public virtual ICollection<User> Users { get; set; } = new List<User>();
}
