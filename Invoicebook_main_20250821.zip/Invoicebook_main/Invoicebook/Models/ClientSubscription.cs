﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class ClientSubscription
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint SubscriptionId { get; set; }

    public uint? RecurringInvoiceId { get; set; }

    public uint ClientId { get; set; }

    public uint? TrialStarted { get; set; }

    public uint? TrialEnds { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? DeletedAt { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public uint? InvoiceId { get; set; }

    public uint Quantity { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual Invoice? Invoice { get; set; }

    public virtual RecurringInvoice? RecurringInvoice { get; set; }

    public virtual Subscription Subscription { get; set; } = null!;
}
