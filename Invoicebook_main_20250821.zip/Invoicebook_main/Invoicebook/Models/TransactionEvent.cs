﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class TransactionEvent
{
    public uint Id { get; set; }

    public uint ClientId { get; set; }

    public uint InvoiceId { get; set; }

    public uint PaymentId { get; set; }

    public uint CreditId { get; set; }

    public decimal ClientBalance { get; set; }

    public decimal ClientPaidToDate { get; set; }

    public decimal ClientCreditBalance { get; set; }

    public decimal InvoiceBalance { get; set; }

    public decimal InvoiceAmount { get; set; }

    public decimal InvoicePartial { get; set; }

    public decimal InvoicePaidToDate { get; set; }

    public uint? InvoiceStatus { get; set; }

    public decimal PaymentAmount { get; set; }

    public decimal PaymentApplied { get; set; }

    public decimal PaymentRefunded { get; set; }

    public uint? PaymentStatus { get; set; }

    public string? Paymentables { get; set; }

    public uint EventId { get; set; }

    public uint Timestamp { get; set; }

    public string? PaymentRequest { get; set; }

    public string? Metadata { get; set; }

    public decimal CreditBalance { get; set; }

    public decimal CreditAmount { get; set; }

    public uint? CreditStatus { get; set; }

    public virtual Client Client { get; set; } = null!;
}
