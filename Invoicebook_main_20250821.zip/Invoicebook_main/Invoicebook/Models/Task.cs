﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Task
{
    public uint Id { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public uint? ClientId { get; set; }

    public uint? InvoiceId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? StatusId { get; set; }

    public int? StatusSortOrder { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public uint? Duration { get; set; }

    public string? Description { get; set; }

    public bool IsDeleted { get; set; }

    public bool IsRunning { get; set; }

    public string? TimeLog { get; set; }

    public string? Number { get; set; }

    public decimal Rate { get; set; }

    public bool InvoiceDocuments { get; set; }

    public bool IsDateBased { get; set; }

    public int? StatusOrder { get; set; }

    public DateOnly? CalculatedStartDate { get; set; }

    public virtual Client? Client { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual Invoice? Invoice { get; set; }

    public virtual User User { get; set; } = null!;
}
