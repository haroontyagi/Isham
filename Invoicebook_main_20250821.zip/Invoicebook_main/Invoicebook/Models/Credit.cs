﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Credit
{
    public uint Id { get; set; }

    public uint ClientId { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public uint StatusId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? VendorId { get; set; }

    public uint? RecurringId { get; set; }

    public uint? DesignId { get; set; }

    public uint? InvoiceId { get; set; }

    public string? Number { get; set; }

    public double Discount { get; set; }

    public bool IsAmountDiscount { get; set; }

    public string? PoNumber { get; set; }

    public DateOnly? Date { get; set; }

    public DateTime? LastSentDate { get; set; }

    public DateOnly? DueDate { get; set; }

    public bool IsDeleted { get; set; }

    public string? LineItems { get; set; }

    public string? Backup { get; set; }

    public string? Footer { get; set; }

    public string? PublicNotes { get; set; }

    public string? PrivateNotes { get; set; }

    public string? Terms { get; set; }

    public string? TaxName1 { get; set; }

    public decimal TaxRate1 { get; set; }

    public string? TaxName2 { get; set; }

    public decimal TaxRate2 { get; set; }

    public string? TaxName3 { get; set; }

    public decimal TaxRate3 { get; set; }

    public decimal TotalTaxes { get; set; }

    public bool UsesInclusiveTaxes { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public DateTime? NextSendDate { get; set; }

    public decimal? CustomSurcharge1 { get; set; }

    public decimal? CustomSurcharge2 { get; set; }

    public decimal? CustomSurcharge3 { get; set; }

    public decimal? CustomSurcharge4 { get; set; }

    public bool CustomSurchargeTax1 { get; set; }

    public bool CustomSurchargeTax2 { get; set; }

    public bool CustomSurchargeTax3 { get; set; }

    public bool CustomSurchargeTax4 { get; set; }

    public decimal ExchangeRate { get; set; }

    public decimal Amount { get; set; }

    public decimal Balance { get; set; }

    public decimal? Partial { get; set; }

    public DateTime? PartialDueDate { get; set; }

    public DateTime? LastViewed { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public DateOnly? Reminder1Sent { get; set; }

    public DateOnly? Reminder2Sent { get; set; }

    public DateOnly? Reminder3Sent { get; set; }

    public DateOnly? ReminderLastSent { get; set; }

    public decimal PaidToDate { get; set; }

    public uint? SubscriptionId { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual ICollection<CreditInvitation> CreditInvitations { get; set; } = new List<CreditInvitation>();

    public virtual User User { get; set; } = null!;
}
