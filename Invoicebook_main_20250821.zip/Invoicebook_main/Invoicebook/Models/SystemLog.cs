﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class SystemLog
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint? UserId { get; set; }

    public uint? ClientId { get; set; }

    public uint? CategoryId { get; set; }

    public uint? EventId { get; set; }

    public uint? TypeId { get; set; }

    public string Log { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual Client? Client { get; set; }

    public virtual Company Company { get; set; } = null!;
}
