﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class CompanyLedger
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint? ClientId { get; set; }

    public uint? UserId { get; set; }

    public uint? ActivityId { get; set; }

    public decimal? Adjustment { get; set; }

    public decimal? Balance { get; set; }

    public string? Notes { get; set; }

    public string? Hash { get; set; }

    public uint CompanyLedgerableId { get; set; }

    public string CompanyLedgerableType { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Client? Client { get; set; }

    public virtual Company Company { get; set; } = null!;
}
