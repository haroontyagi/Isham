﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class RecurringInvoice
{
    public uint Id { get; set; }

    public uint ClientId { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? VendorId { get; set; }

    public uint StatusId { get; set; }

    public string? Number { get; set; }

    public double Discount { get; set; }

    public bool IsAmountDiscount { get; set; }

    public string? PoNumber { get; set; }

    public DateOnly? Date { get; set; }

    public DateTime? DueDate { get; set; }

    public bool IsDeleted { get; set; }

    public string? LineItems { get; set; }

    public string? Backup { get; set; }

    public string? Footer { get; set; }

    public string? PublicNotes { get; set; }

    public string? PrivateNotes { get; set; }

    public string? Terms { get; set; }

    public string? TaxName1 { get; set; }

    public decimal TaxRate1 { get; set; }

    public string? TaxName2 { get; set; }

    public decimal TaxRate2 { get; set; }

    public string? TaxName3 { get; set; }

    public decimal TaxRate3 { get; set; }

    public decimal TotalTaxes { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public decimal Amount { get; set; }

    public decimal Balance { get; set; }

    public decimal? Partial { get; set; }

    public DateTime? LastViewed { get; set; }

    public uint FrequencyId { get; set; }

    public DateTime? LastSentDate { get; set; }

    public DateTime? NextSendDate { get; set; }

    public int? RemainingCycles { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string AutoBill { get; set; } = null!;

    public bool AutoBillEnabled { get; set; }

    public uint? DesignId { get; set; }

    public bool UsesInclusiveTaxes { get; set; }

    public decimal? CustomSurcharge1 { get; set; }

    public decimal? CustomSurcharge2 { get; set; }

    public decimal? CustomSurcharge3 { get; set; }

    public decimal? CustomSurcharge4 { get; set; }

    public bool CustomSurchargeTax1 { get; set; }

    public bool CustomSurchargeTax2 { get; set; }

    public bool CustomSurchargeTax3 { get; set; }

    public bool CustomSurchargeTax4 { get; set; }

    public string? DueDateDays { get; set; }

    public DateOnly? PartialDueDate { get; set; }

    public decimal ExchangeRate { get; set; }

    public decimal PaidToDate { get; set; }

    public uint? SubscriptionId { get; set; }

    public DateTime? NextSendDateClient { get; set; }

    public bool IsProforma { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual ICollection<ClientSubscription> ClientSubscriptions { get; set; } = new List<ClientSubscription>();

    public virtual Company Company { get; set; } = null!;

    public virtual ICollection<RecurringInvoiceInvitation> RecurringInvoiceInvitations { get; set; } = new List<RecurringInvoiceInvitation>();

    public virtual ICollection<RecurringQuoteInvitation> RecurringQuoteInvitations { get; set; } = new List<RecurringQuoteInvitation>();

    public virtual User User { get; set; } = null!;
}
