﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class BankSubcompany
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public uint BankCompanyId { get; set; }

    public string? AccountName { get; set; }

    public string? Website { get; set; }

    public string? AccountNumber { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual BankCompany BankCompany { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
