﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class PaymentTerm
{
    public uint Id { get; set; }

    public int? NumDays { get; set; }

    public string? Name { get; set; }

    public uint? CompanyId { get; set; }

    public uint? UserId { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual Company? Company { get; set; }

    public virtual User? User { get; set; }
}
