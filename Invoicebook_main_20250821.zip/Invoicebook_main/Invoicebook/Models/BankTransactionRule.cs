﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class BankTransactionRule
{
    public ulong Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public string Name { get; set; } = null!;

    public string? Rules { get; set; }

    public bool AutoConvert { get; set; }

    public bool MatchesOnAll { get; set; }

    public string AppliesTo { get; set; } = null!;

    public uint? ClientId { get; set; }

    public uint? VendorId { get; set; }

    public uint? CategoryId { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
