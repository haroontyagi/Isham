﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models
{
    public partial class Product
    {
        public uint Id { get; set; }
        public uint UserId { get; set; }
        public uint? AssignedUserId { get; set; }
        public uint CompanyId { get; set; }
        public uint? ClientId { get; set; }
        public string Name { get; set; } = null!;
        public decimal TaskRate { get; set; }
        public DateOnly? DueDate { get; set; }
        public string? PrivateNotes { get; set; }
        public decimal BudgetedHours { get; set; }
        public string? CustomValue1 { get; set; }
        public string? CustomValue2 { get; set; }
        public string? CustomValue3 { get; set; }
        public string? CustomValue4 { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public DateTime? DeletedAt { get; set; }
        public string? PublicNotes { get; set; }
        public bool IsDeleted { get; set; }
        public string? Number { get; set; }
        public string Color { get; set; } = null!;
        public uint? CurrentHours { get; set; }

        public virtual Company Company { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}
