﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class ExpenseCategory
{
    public uint Id { get; set; }

    public uint UserId { get; set; }

    public uint CompanyId { get; set; }

    public string? Name { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool IsDeleted { get; set; }

    public string Color { get; set; } = null!;

    public uint? BankCategoryId { get; set; }

    public virtual Company Company { get; set; } = null!;
}
