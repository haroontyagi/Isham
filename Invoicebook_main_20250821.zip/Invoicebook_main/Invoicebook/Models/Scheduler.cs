﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Scheduler
{
    public ulong Id { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? Parameters { get; set; }

    public uint CompanyId { get; set; }

    public bool IsPaused { get; set; }

    public uint? FrequencyId { get; set; }

    public DateTime? NextRun { get; set; }

    public DateTime? NextRunClient { get; set; }

    public uint UserId { get; set; }

    public string? Name { get; set; }

    public string Template { get; set; } = null!;

    public int? RemainingCycles { get; set; }

    public virtual Company Company { get; set; } = null!;
}
