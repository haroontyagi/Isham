﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Invoicebook.Models
{
    [Table("client_contacts")]
    public partial class ClientContact
    {
        public uint Id { get; set; }

        [Column("company_id")]
        public uint CompanyId { get; set; }

        [Column("client_id")]
        public uint ClientId { get; set; }

        [Column("user_id")]
        public uint UserId { get; set; }

        [Column("first_name")]
        public string? FirstName { get; set; }

        [Column("last_name")]
        public string? LastName { get; set; }

        public string? Phone { get; set; }

        [Column("custom_value1")]
        public string? CustomValue1 { get; set; }

        [Column("custom_value2")]
        public string? CustomValue2 { get; set; }

        [Column("custom_value3")]
        public string? CustomValue3 { get; set; }

        [Column("custom_value4")]
        public string? CustomValue4 { get; set; }

        public string? Email { get; set; }

        [Column("email_verified_at")]
        public DateTime? EmailVerifiedAt { get; set; }

        [Column("confirmation_code")]
        public string? ConfirmationCode { get; set; }

        [Column("is_primary")]
        public bool IsPrimary { get; set; }

        public bool Confirmed { get; set; }

        [Column("last_login")]
        public DateTime? LastLogin { get; set; }

        [Column("failed_logins")]
        public short? FailedLogins { get; set; }

        [Column("oauth_user_id")]
        public string? OauthUserId { get; set; }

        [Column("oauth_provider_id")]
        public uint? OauthProviderId { get; set; }

        [Column("google_2fa_secret")]
        public string? Google2faSecret { get; set; }

        [Column("accepted_terms_version")]
        public string? AcceptedTermsVersion { get; set; }

        public string? Avatar { get; set; }

        [Column("avatar_type")]
        public string? AvatarType { get; set; }

        [Column("avatar_size")]
        public string? AvatarSize { get; set; }

        public string Password { get; set; } = null!;

        public string? Token { get; set; }

        [Column("is_locked")]
        public bool IsLocked { get; set; }

        [Column("send_email")]
        public bool? SendEmail { get; set; }

        [Column("contact_key")]
        public string? ContactKey { get; set; }

        [Column("remember_token")]
        public string? RememberToken { get; set; }

        [Column("created_at")]
        public DateTime? CreatedAt { get; set; }

        [Column("updated_at")]
        public DateTime? UpdatedAt { get; set; }

        [Column("deleted_at")]
        public DateTime? DeletedAt { get; set; }

        // Navigation property to Client
        public virtual Client Client { get; set; } = null!;

        // Navigation collections (mapped to related tables)
        public virtual ICollection<CreditInvitation> CreditInvitations { get; set; } = new List<CreditInvitation>();
        public virtual ICollection<InvoiceInvitation> InvoiceInvitations { get; set; } = new List<InvoiceInvitation>();
        public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
        public virtual ICollection<QuoteInvitation> QuoteInvitations { get; set; } = new List<QuoteInvitation>();
        public virtual ICollection<RecurringInvoiceInvitation> RecurringInvoiceInvitations { get; set; } = new List<RecurringInvoiceInvitation>();
        public virtual ICollection<RecurringQuoteInvitation> RecurringQuoteInvitations { get; set; } = new List<RecurringQuoteInvitation>();
    }
}
