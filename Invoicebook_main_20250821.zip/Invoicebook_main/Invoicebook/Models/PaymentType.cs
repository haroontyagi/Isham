﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class PaymentType
{
    public uint Id { get; set; }

    public string Name { get; set; } = null!;

    public int? GatewayTypeId { get; set; }
}
