﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Currency
{
    public uint Id { get; set; }

    public string Name { get; set; } = null!;

    public string Symbol { get; set; } = null!;

    public string Precision { get; set; } = null!;

    public string ThousandSeparator { get; set; } = null!;

    public string DecimalSeparator { get; set; } = null!;

    public string Code { get; set; } = null!;

    public bool SwapCurrencySymbol { get; set; }

    public decimal ExchangeRate { get; set; }

    public virtual ICollection<Vendor> Vendors { get; set; } = new List<Vendor>();
}
