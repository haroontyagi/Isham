﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Company
{
    public uint Id { get; set; }

    public uint AccountId { get; set; }

    public uint? IndustryId { get; set; }

    public string? Ip { get; set; }

    public string CompanyKey { get; set; } = null!;

    public bool ConvertProducts { get; set; }

    public bool? FillProducts { get; set; }

    public bool? UpdateProducts { get; set; }

    public bool? ShowProductDetails { get; set; }

    public bool ClientCanRegister { get; set; }

    public bool CustomSurchargeTaxes1 { get; set; }

    public bool CustomSurchargeTaxes2 { get; set; }

    public bool CustomSurchargeTaxes3 { get; set; }

    public bool CustomSurchargeTaxes4 { get; set; }

    public bool ShowProductCost { get; set; }

    public uint EnabledTaxRates { get; set; }

    public uint EnabledModules { get; set; }

    public bool EnableProductCost { get; set; }

    public bool? EnableProductQuantity { get; set; }

    public bool? DefaultQuantity { get; set; }

    public string? Subdomain { get; set; }

    public string? Db { get; set; }

    public uint? SizeId { get; set; }

    public string? FirstDayOfWeek { get; set; }

    public string? FirstMonthOfYear { get; set; }

    public string PortalMode { get; set; } = null!;

    public string? PortalDomain { get; set; }

    public short EnableModules { get; set; }

    public string CustomFields { get; set; } = null!;

    public string Settings { get; set; } = null!;

    public string SlackWebhookUrl { get; set; } = null!;

    public string GoogleAnalyticsKey { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public int EnabledItemTaxRates { get; set; }

    public bool IsLarge { get; set; }

    public bool EnableShopApi { get; set; }

    public string DefaultAutoBill { get; set; } = null!;

    public bool MarkExpensesInvoiceable { get; set; }

    public bool MarkExpensesPaid { get; set; }

    public bool InvoiceExpenseDocuments { get; set; }

    public bool AutoStartTasks { get; set; }

    public bool? InvoiceTaskTimelog { get; set; }

    public bool InvoiceTaskDocuments { get; set; }

    public bool ShowTasksTable { get; set; }

    public bool IsDisabled { get; set; }

    public bool DefaultTaskIsDateBased { get; set; }

    public bool EnableProductDiscount { get; set; }

    public bool CalculateExpenseTaxByAmount { get; set; }

    public bool ExpenseInclusiveTaxes { get; set; }

    public int SessionTimeout { get; set; }

    public bool OauthPasswordRequired { get; set; }

    public bool? InvoiceTaskDatelog { get; set; }

    public int DefaultPasswordTimeout { get; set; }

    public bool ShowTaskEndDate { get; set; }

    public bool? MarkdownEnabled { get; set; }

    public bool UseCommaAsDecimalPlace { get; set; }

    public bool ReportIncludeDrafts { get; set; }

    public string? ClientRegistrationFields { get; set; }

    public bool? ConvertRateToClient { get; set; }

    public bool MarkdownEmailEnabled { get; set; }

    public bool StopOnUnpaidRecurring { get; set; }

    public bool UseQuoteTermsOnConversion { get; set; }

    public bool EnableApplyingPayments { get; set; }

    public bool TrackInventory { get; set; }

    public int InventoryNotificationThreshold { get; set; }

    public bool? StockNotification { get; set; }

    public string? MatomoUrl { get; set; }

    public long? MatomoId { get; set; }

    public uint EnabledExpenseTaxRates { get; set; }

    public bool InvoiceTaskProject { get; set; }

    public bool ReportIncludeDeleted { get; set; }

    public bool InvoiceTaskLock { get; set; }

    public bool ConvertPaymentCurrency { get; set; }

    public bool ConvertExpenseCurrency { get; set; }

    public bool NotifyVendorWhenPaid { get; set; }

    public bool InvoiceTaskHours { get; set; }

    public bool CalculateTaxes { get; set; }

    public string? TaxData { get; set; }

    public string? ShopifyName { get; set; }

    public string? ShopifyAccessToken { get; set; }

    public string? EInvoiceCertificate { get; set; }

    public string? EInvoiceCertificatePassphrase { get; set; }

    public string? OriginTaxData { get; set; }

    public bool? InvoiceTaskProjectHeader { get; set; }

    public bool? InvoiceTaskItemDescription { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual ICollection<Activity> Activities { get; set; } = new List<Activity>();

    public virtual ICollection<BankCompany> BankCompanies { get; set; } = new List<BankCompany>();

    public virtual ICollection<BankIntegration> BankIntegrations { get; set; } = new List<BankIntegration>();

    public virtual ICollection<BankSubcompany> BankSubcompanies { get; set; } = new List<BankSubcompany>();

    public virtual ICollection<BankTransactionRule> BankTransactionRules { get; set; } = new List<BankTransactionRule>();

    public virtual ICollection<BankTransaction> BankTransactions { get; set; } = new List<BankTransaction>();

    public virtual ICollection<ClientGatewayToken> ClientGatewayTokens { get; set; } = new List<ClientGatewayToken>();

    public virtual ICollection<ClientSubscription> ClientSubscriptions { get; set; } = new List<ClientSubscription>();

    public virtual ICollection<Client> Clients { get; set; } = new List<Client>();

    public virtual ICollection<CompanyGateway> CompanyGateways { get; set; } = new List<CompanyGateway>();

    public virtual ICollection<CompanyLedger> CompanyLedgers { get; set; } = new List<CompanyLedger>();

    public virtual ICollection<CompanyToken> CompanyTokens { get; set; } = new List<CompanyToken>();

    public virtual ICollection<CompanyUser> CompanyUsers { get; set; } = new List<CompanyUser>();

    public virtual ICollection<CreditInvitation> CreditInvitations { get; set; } = new List<CreditInvitation>();

    public virtual ICollection<Credit> Credits { get; set; } = new List<Credit>();

    public virtual ICollection<Design> Designs { get; set; } = new List<Design>();

    public virtual ICollection<Document> Documents { get; set; } = new List<Document>();

    public virtual ICollection<ExpenseCategory> ExpenseCategories { get; set; } = new List<ExpenseCategory>();

    public virtual ICollection<Expense> Expenses { get; set; } = new List<Expense>();

    public virtual ICollection<GroupSetting> GroupSettings { get; set; } = new List<GroupSetting>();

    public virtual Industry? Industry { get; set; }

    public virtual ICollection<InvoiceInvitation> InvoiceInvitations { get; set; } = new List<InvoiceInvitation>();

    public virtual ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();

    public virtual ICollection<PaymentTerm> PaymentTerms { get; set; } = new List<PaymentTerm>();

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    //public virtual ICollection<Product> Products { get; set; } = new List<Product>();

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();

    public virtual ICollection<PurchaseOrderInvitation> PurchaseOrderInvitations { get; set; } = new List<PurchaseOrderInvitation>();

    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = new List<PurchaseOrder>();

    public virtual ICollection<QuoteInvitation> QuoteInvitations { get; set; } = new List<QuoteInvitation>();

    public virtual ICollection<Quote> Quotes { get; set; } = new List<Quote>();

    public virtual ICollection<RecurringExpense> RecurringExpenses { get; set; } = new List<RecurringExpense>();

    public virtual ICollection<RecurringInvoiceInvitation> RecurringInvoiceInvitations { get; set; } = new List<RecurringInvoiceInvitation>();

    public virtual ICollection<RecurringInvoice> RecurringInvoices { get; set; } = new List<RecurringInvoice>();

    public virtual ICollection<RecurringQuoteInvitation> RecurringQuoteInvitations { get; set; } = new List<RecurringQuoteInvitation>();

    public virtual ICollection<RecurringQuote> RecurringQuotes { get; set; } = new List<RecurringQuote>();

    public virtual ICollection<Scheduler> Schedulers { get; set; } = new List<Scheduler>();

    public virtual Size? Size { get; set; }

    public virtual ICollection<Subscription> Subscriptions { get; set; } = new List<Subscription>();

    public virtual ICollection<SystemLog> SystemLogs { get; set; } = new List<SystemLog>();

    public virtual ICollection<TaskStatus> TaskStatuses { get; set; } = new List<TaskStatus>();

    public virtual ICollection<Task> Tasks { get; set; } = new List<Task>();

    public virtual ICollection<TaxRate> TaxRates { get; set; } = new List<TaxRate>();

    public virtual ICollection<VendorContact> VendorContacts { get; set; } = new List<VendorContact>();

    public virtual ICollection<Vendor> Vendors { get; set; } = new List<Vendor>();

    public virtual ICollection<Webhook> Webhooks { get; set; } = new List<Webhook>();
}
