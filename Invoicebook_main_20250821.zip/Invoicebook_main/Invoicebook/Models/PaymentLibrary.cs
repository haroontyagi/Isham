﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class PaymentLibrary
{
    public uint Id { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public string? Name { get; set; }

    public bool? Visible { get; set; }
}
