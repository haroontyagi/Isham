﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class CompanyToken
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint AccountId { get; set; }

    public uint UserId { get; set; }

    public string? Token { get; set; }

    public string? Name { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool IsDeleted { get; set; }

    public bool IsSystem { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
