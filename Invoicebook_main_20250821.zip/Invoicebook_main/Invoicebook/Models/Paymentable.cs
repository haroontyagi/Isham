﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Paymentable
{
    public uint Id { get; set; }

    public uint PaymentId { get; set; }

    public uint PaymentableId { get; set; }

    public decimal Amount { get; set; }

    public decimal Refunded { get; set; }

    public string PaymentableType { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual Payment Payment { get; set; } = null!;
}
