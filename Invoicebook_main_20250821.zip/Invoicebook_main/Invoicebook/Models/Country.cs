﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Country
{
    public uint Id { get; set; }

    public string? Capital { get; set; }

    public string? Citizenship { get; set; }

    public string? CountryCode { get; set; }

    public string? Currency { get; set; }

    public string? CurrencyCode { get; set; }

    public string? CurrencySubUnit { get; set; }

    public string? FullName { get; set; }

    public string? Iso31662 { get; set; }

    public string? Iso31663 { get; set; }

    public string? Name { get; set; }

    public string? RegionCode { get; set; }

    public string? SubRegionCode { get; set; }

    public bool Eea { get; set; }

    public bool SwapPostalCode { get; set; }

    public bool SwapCurrencySymbol { get; set; }

    public string? ThousandSeparator { get; set; }

    public string? DecimalSeparator { get; set; }

    public virtual ICollection<Vendor> Vendors { get; set; } = new List<Vendor>();
}
