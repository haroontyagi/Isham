﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class GroupSetting
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint? UserId { get; set; }

    public string? Name { get; set; }

    public string? Settings { get; set; }

    public bool IsDefault { get; set; }

    public DateTime? DeletedAt { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool IsDeleted { get; set; }

    public virtual Company Company { get; set; } = null!;
}
