﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class CompanyGateway
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public string GatewayKey { get; set; } = null!;

    public uint AcceptedCreditCards { get; set; }

    public bool? RequireCvv { get; set; }

    public bool? RequireBillingAddress { get; set; }

    public bool? RequireShippingAddress { get; set; }

    public bool? UpdateDetails { get; set; }

    public bool IsDeleted { get; set; }

    public string Config { get; set; } = null!;

    public string FeesAndLimits { get; set; } = null!;

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string TokenBilling { get; set; } = null!;

    public string? Label { get; set; }

    public bool RequireClientName { get; set; }

    public bool RequirePostalCode { get; set; }

    public bool RequireClientPhone { get; set; }

    public bool RequireContactName { get; set; }

    public bool RequireContactEmail { get; set; }

    public bool RequireCustomValue1 { get; set; }

    public bool RequireCustomValue2 { get; set; }

    public bool RequireCustomValue3 { get; set; }

    public bool RequireCustomValue4 { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual Gateway GatewayKeyNavigation { get; set; } = null!;

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    public virtual User User { get; set; } = null!;
}
