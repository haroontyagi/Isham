﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Invoicebook.Models;
using Invoicebook.ViewModel;
using Invoicebook.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

public class ClientController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ICompositeViewEngine _viewEngine;
    private readonly ITempDataProvider _tempDataProvider;

    public ClientController(ApplicationDbContext context, ICompositeViewEngine viewEngine, ITempDataProvider tempDataProvider)
    {
        _context = context;
        _viewEngine = viewEngine;
        _tempDataProvider = tempDataProvider;
    }

    public IActionResult Index() => View();

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var clients = await _context.Clients
            .Include(c => c.ClientContacts)
            .Where(c => !c.IsDeleted)
            .Select(c => new
            {
                id = c.Id,
                number = c.Number,
                name = c.Name,
                balance = c.Balance,
                paidDate = c.PaidToDate,
                contactName = c.ClientContacts.Select(cc => (cc.FirstName + " " + cc.LastName).Trim()).FirstOrDefault() ?? "",
                createdAt = c.CreatedAt.HasValue ? c.CreatedAt.Value.ToString("o") : null
            }).ToListAsync();

        return Json(clients);
    }

    // CREATE - GET modal
    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var users = await _context.Users.ToListAsync();
        var userSelectList = new SelectList(users.Select(u => new { u.Id, Name = (u.FirstName ?? "") + " " + (u.LastName ?? "") }), "Id", "Name");

        var vm = new ClientCreateEditViewModel
        {
            Contacts = new List<ClientContactViewModel> { new ClientContactViewModel() },
            UsersSelectList = userSelectList
        };

        return PartialView("_CreateClientPartial", vm);
    }

    // CREATE - POST ajax
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ClientCreateEditViewModel vm)
    {
        if (!ModelState.IsValid)
        {
            string html = await RenderPartialViewToStringAsync("_CreateClientPartial", vm);
            return Json(new { success = false, html });
        }

        try
        {
            var client = new Client
            {
                Name = vm.Name,
                Number = vm.Number,
                Phone = vm.Phone,
                Website = vm.Website,
                IdNumber = vm.IdNumber,
                VatNumber = vm.VatNumber,
                Address1 = vm.Address1,
                Address2 = vm.Address2,
                City = vm.City,
                State = vm.State,
                PostalCode = vm.PostalCode,
                CountryId = vm.CountryId,
                ShippingAddress1 = vm.ShippingAddress1,
                ShippingAddress2 = vm.ShippingAddress2,
                ShippingCity = vm.ShippingCity,
                ShippingState = vm.ShippingState,
                ShippingPostalCode = vm.ShippingPostalCode,
                ShippingCountryId = vm.ShippingCountryId,
                PublicNotes = vm.PublicNotes,
                PrivateNotes = vm.PrivateNotes,
                ClientContacts = vm.Contacts.Select(c => new ClientContact
                {
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    Email = c.Email,
                    Phone = c.Phone
                }).ToList()
            };

            _context.Clients.Add(client);
            await _context.SaveChangesAsync();

            return Json(new { success = true });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, html = "<div class='alert alert-danger'>Server error: " + ex.Message + "</div>" });
        }
    }

    // EDIT - GET modal
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var client = await _context.Clients.Include(c => c.ClientContacts)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

        if (client == null) return NotFound();

        var users = await _context.Users.ToListAsync();
        var userSelectList = new SelectList(users.Select(u => new { u.Id, Name = (u.FirstName ?? "") + " " + (u.LastName ?? "") }), "Id", "Name");

        var vm = new ClientCreateEditViewModel
        {
            Id = client.Id,
            Name = client.Name,
            Number = client.Number,
            Phone = client.Phone,
            Website = client.Website,
            IdNumber = client.IdNumber,
            VatNumber = client.VatNumber,
            Address1 = client.Address1,
            Address2 = client.Address2,
            City = client.City,
            State = client.State,
            PostalCode = client.PostalCode,
            CountryId = client.CountryId,
            ShippingAddress1 = client.ShippingAddress1,
            ShippingAddress2 = client.ShippingAddress2,
            ShippingCity = client.ShippingCity,
            ShippingState = client.ShippingState,
            ShippingPostalCode = client.ShippingPostalCode,
            ShippingCountryId = client.ShippingCountryId,
            PublicNotes = client.PublicNotes,
            PrivateNotes = client.PrivateNotes,
            Contacts = client.ClientContacts.Select(cc => new ClientContactViewModel
            {
                Id = cc.Id,
                FirstName = cc.FirstName,
                LastName = cc.LastName,
                Email = cc.Email,
                Phone = cc.Phone
            }).ToList(),
            UsersSelectList = userSelectList,
            UserId = client.UserId // Make sure UserId exists in ClientCreateEditViewModel to bind selection
        };

        return PartialView("_EditClientPartial", vm);
    }

    // EDIT - POST ajax
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ClientCreateEditViewModel vm)
    {
        if (id != vm.Id) return BadRequest();

        if (!ModelState.IsValid)
        {
            string html = await RenderPartialViewToStringAsync("_EditClientPartial", vm);
            return Json(new { success = false, html });
        }

        var client = await _context.Clients.Include(c => c.ClientContacts).FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (client == null) return NotFound();

        // Update fields
        client.Name = vm.Name;
        client.Number = vm.Number;
        client.Phone = vm.Phone;
        client.Website = vm.Website;
        client.IdNumber = vm.IdNumber;
        client.VatNumber = vm.VatNumber;
        client.Address1 = vm.Address1;
        client.Address2 = vm.Address2;
        client.City = vm.City;
        client.State = vm.State;
        client.PostalCode = vm.PostalCode;
        client.CountryId = vm.CountryId;
        client.ShippingAddress1 = vm.ShippingAddress1;
        client.ShippingAddress2 = vm.ShippingAddress2;
        client.ShippingCity = vm.ShippingCity;
        client.ShippingState = vm.ShippingState;
        client.ShippingPostalCode = vm.ShippingPostalCode;
        client.ShippingCountryId = vm.ShippingCountryId;
        client.PublicNotes = vm.PublicNotes;
        client.PrivateNotes = vm.PrivateNotes;

        // Clear existing contacts and add new
        client.ClientContacts.Clear();
        foreach (var c in vm.Contacts)
        {
            client.ClientContacts.Add(new ClientContact
            {
                Id = c.Id ?? 0,
                FirstName = c.FirstName,
                LastName = c.LastName,
                Email = c.Email,
                Phone = c.Phone
            });
        }

        await _context.SaveChangesAsync();

        return Json(new { success = true });
    }

    // DETAILS modal
    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var client = await _context.Clients.Include(c => c.ClientContacts)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (client == null) return NotFound();

        var vm = new ClientDetailsViewModel
        {
            Id = client.Id,
            Name = client.Name,
            Number = client.Number,
            Balance = client.Balance,
            PaidToDate = client.PaidToDate,
            Address1 = client.Address1,
            City = client.City,
            State = client.State,
            PostalCode = client.PostalCode,
            Contacts = client.ClientContacts.Select(cc => new ClientContactViewModel
            {
                FirstName = cc.FirstName,
                LastName = cc.LastName,
                Email = cc.Email,
                Phone = cc.Phone
            }).ToList()
        };

        return PartialView("_DetailsClientPartial", vm);
    }

    // DELETE ajax
    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var client = await _context.Clients.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
        if (client == null)
            return Json(new { success = false, message = "Client not found" });

        client.IsDeleted = true;
        client.DeletedAt = DateTime.UtcNow;
        client.UpdatedAt = DateTime.UtcNow;

        _context.Clients.Update(client);
        await _context.SaveChangesAsync();

        return Json(new { success = true });
    }

    // Helper to render partial view to string for AJAX validation errors
    private async Task<string> RenderPartialViewToStringAsync(string viewName, object model)
    {
        ViewData.Model = model;

        using var sw = new StringWriter();
        var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);
        if (viewResult.View == null)
            throw new ArgumentNullException($"{viewName} does not match any available view");

        var viewContext = new ViewContext(
            ControllerContext,
            viewResult.View,
            ViewData,
            TempData,
            sw,
            new HtmlHelperOptions()
        );

        await viewResult.View.RenderAsync(viewContext);
        return sw.GetStringBuilder().ToString();
    }
}
