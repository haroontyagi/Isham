using Invoicebook.Models;
using Microsoft.EntityFrameworkCore;

namespace Invoicebook.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }


        public DbSet<Client> Clients { get; set; }
        public DbSet<ClientContact> ClientContacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Client>()
                .HasMany(c => c.ClientContacts)
                .WithOne(cc => cc.Client)
                .HasForeignKey(cc => cc.ClientId);
        }


    }
}

