﻿using Microsoft.AspNetCore.Mvc;

namespace Invoicebook.Controllers
{
    public class ChartController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
