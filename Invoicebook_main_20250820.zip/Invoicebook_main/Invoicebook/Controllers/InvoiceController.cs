﻿// Controllers/InvoiceController.cs
using Microsoft.AspNetCore.Mvc;

public class InvoiceController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}
