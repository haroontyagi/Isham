﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Invoicebook.Models;
using Invoicebook.ViewModels;
using Invoicebook.Data;


public class ClientController : Controller
{
    private readonly ApplicationDbContext _context;

    public ClientController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    // Get all clients for DataTables
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var clients = await _context.Clients
            .Include(c => c.ClientContacts)
            .Where(c => !c.IsDeleted)
            .Select(c => new
            {
                id = c.Id,
                number = c.Number,
                name = c.Name,
                balance = c.Balance,
                paidDate = c.PaidToDate,
                contactName = c.ClientContacts.Select(cc => (cc.FirstName + " " + cc.LastName).Trim()).FirstOrDefault(),
                contactEmail = c.ClientContacts.Select(cc => cc.Email).FirstOrDefault(),
                contactPhone = c.ClientContacts.Select(cc => cc.Phone).FirstOrDefault(),
                billingStreet = c.Address1,
                billingCity = c.City,
                billingState = c.State,
                billingPostalCode = c.PostalCode,
                billingCountry = c.CountryId,
                createdAt = c.CreatedAt.HasValue ? c.CreatedAt.Value.ToString("o") : null
            })
            .ToListAsync();

        return Json(clients);
    }

    [HttpGet]
    public IActionResult Create()
    {
        var model = new Client
        {
            CompanyId = 1,
            UserId = 1,
            CreatedAt = System.DateTime.UtcNow,
            ClientContacts = new List<ClientContact> { new ClientContact() }
        };
        return PartialView("_CreateClientPartial", model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Client model)
    {
        if (!ModelState.IsValid)
            return PartialView("_CreateClientPartial", model);

        model.CompanyId = model.CompanyId == 0 ? 1 : model.CompanyId;
        model.UserId = model.UserId == 0 ? 1 : model.UserId;
        model.Balance = 0;
        model.PaidToDate = 0;
        model.CreditBalance = 0;
        model.PaymentBalance = 0;
        model.IsDeleted = false;
        model.CreatedAt = System.DateTime.UtcNow;
        model.UpdatedAt = System.DateTime.UtcNow;
        if (string.IsNullOrEmpty(model.Number))
        {
            var lastClient = await _context.Clients.OrderByDescending(c => c.Id).FirstOrDefaultAsync();
            var nextId = (lastClient?.Id ?? 0) + 1;
            model.Number = $"CL{nextId:D4}";
        }
        var contacts = model.ClientContacts ?? new List<ClientContact>();
        model.ClientContacts = null;
        _context.Clients.Add(model);
        await _context.SaveChangesAsync();

        foreach (var contact in contacts)
        {
            contact.ClientId = model.Id;
            contact.CompanyId = model.CompanyId;
            contact.UserId = model.UserId;
            _context.ClientContacts.Add(contact);
        }
        await _context.SaveChangesAsync();

        return Json(new { success = true, redirectUrl = Url.Action(nameof(Index)) });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var client = await _context.Clients
            .Include(c => c.ClientContacts)
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
        if (client == null) return NotFound();

        if (!client.ClientContacts.Any())
            client.ClientContacts.Add(new ClientContact());

        return PartialView("_EditClientPartial", client);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Client model)
    {
        if (id != model.Id) return BadRequest();

        if (!ModelState.IsValid)
            return PartialView("_EditClientPartial", model);

        var client = await _context.Clients
            .Include(c => c.ClientContacts)
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
        if (client == null) return NotFound();

        client.Name = model.Name;
        client.Number = model.Number;
        client.Phone = model.Phone;
        client.Website = model.Website;
        client.Balance = model.Balance;
        client.PaidToDate = model.PaidToDate;
        client.Address1 = model.Address1;
        client.Address2 = model.Address2;
        client.City = model.City;
        client.State = model.State;
        client.PostalCode = model.PostalCode;
        client.CountryId = model.CountryId;
        client.ShippingAddress1 = model.ShippingAddress1;
        client.ShippingAddress2 = model.ShippingAddress2;
        client.ShippingCity = model.ShippingCity;
        client.ShippingState = model.ShippingState;
        client.ShippingPostalCode = model.ShippingPostalCode;
        client.ShippingCountryId = model.ShippingCountryId;
        client.IdNumber = model.IdNumber;
        client.VatNumber = model.VatNumber;
        client.UpdatedAt = System.DateTime.UtcNow;

        foreach (var contact in model.ClientContacts)
        {
            if (contact.Id > 0)
            {
                var existingContact = client.ClientContacts.FirstOrDefault(c => c.Id == contact.Id);
                if (existingContact != null)
                {
                    existingContact.FirstName = contact.FirstName;
                    existingContact.LastName = contact.LastName;
                    existingContact.Email = contact.Email;
                    existingContact.Phone = contact.Phone;
                }
            }
            else
            {
                contact.ClientId = client.Id;
                contact.CompanyId = client.CompanyId;
                contact.UserId = client.UserId;
                _context.ClientContacts.Add(contact);
            }
        }
        await _context.SaveChangesAsync();

        return Json(new { success = true, redirectUrl = Url.Action(nameof(Index)) });
    }


    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var client = await _context.Clients.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
        if (client == null)
        {
            return Json(new { success = false, message = "Client not found" });
        }
        client.IsDeleted = true;
        client.DeletedAt = DateTime.UtcNow;
        client.UpdatedAt = DateTime.UtcNow;
        _context.Clients.Update(client);
        await _context.SaveChangesAsync();
        return Json(new { success = true });
    }
    
    // GET: Client/Details/{id}
    public async Task<IActionResult> Details(int id)
    {
        var client = await _context.Clients
            .Include(c => c.ClientContacts)
            .Include(c => c.Invoices)
            .Include(c => c.Projects)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

        if (client == null)
        {
            return NotFound();
        }

        return PartialView("_DetailsClientPartial", client); // Partial view for modal
    }
        
}
