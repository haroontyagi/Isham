﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class BankIntegration
{
    public ulong Id { get; set; }

    public uint AccountId { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public string ProviderName { get; set; } = null!;

    public long ProviderId { get; set; }

    public long BankAccountId { get; set; }

    public string? BankAccountName { get; set; }

    public string? BankAccountNumber { get; set; }

    public string? BankAccountStatus { get; set; }

    public string? BankAccountType { get; set; }

    public decimal Balance { get; set; }

    public string? Currency { get; set; }

    public string Nickname { get; set; } = null!;

    public DateOnly? FromDate { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool DisabledUpstream { get; set; }

    public bool AutoSync { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual ICollection<BankTransaction> BankTransactions { get; set; } = new List<BankTransaction>();

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
