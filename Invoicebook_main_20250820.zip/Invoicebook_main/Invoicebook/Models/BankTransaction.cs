﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class BankTransaction
{
    public ulong Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public ulong BankIntegrationId { get; set; }

    public ulong TransactionId { get; set; }

    public decimal Amount { get; set; }

    public string? CurrencyCode { get; set; }

    public uint? CurrencyId { get; set; }

    public string? AccountType { get; set; }

    public uint? CategoryId { get; set; }

    public uint? NinjaCategoryId { get; set; }

    public string CategoryType { get; set; } = null!;

    public string BaseType { get; set; } = null!;

    public DateOnly? Date { get; set; }

    public ulong BankAccountId { get; set; }

    public string? Description { get; set; }

    public string InvoiceIds { get; set; } = null!;

    public string? ExpenseId { get; set; }

    public uint? VendorId { get; set; }

    public uint StatusId { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public long? BankTransactionRuleId { get; set; }

    public uint? PaymentId { get; set; }

    public virtual BankIntegration BankIntegration { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
