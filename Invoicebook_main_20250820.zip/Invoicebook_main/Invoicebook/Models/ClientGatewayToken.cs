﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class ClientGatewayToken
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint? ClientId { get; set; }

    public string? Token { get; set; }

    public string? RoutingNumber { get; set; }

    public uint CompanyGatewayId { get; set; }

    public string? GatewayCustomerReference { get; set; }

    public uint GatewayTypeId { get; set; }

    public bool IsDefault { get; set; }

    public string? Meta { get; set; }

    public DateTime? DeletedAt { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool IsDeleted { get; set; }

    public virtual Client? Client { get; set; }

    public virtual Company Company { get; set; } = null!;
}
