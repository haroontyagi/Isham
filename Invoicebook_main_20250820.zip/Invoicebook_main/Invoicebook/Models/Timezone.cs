﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Timezone
{
    public uint Id { get; set; }

    public string Name { get; set; } = null!;

    public string Location { get; set; } = null!;

    public int UtcOffset { get; set; }
}
