﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class DateFormat
{
    public uint Id { get; set; }

    public string Format { get; set; } = null!;

    public string FormatMoment { get; set; } = null!;

    public string FormatDart { get; set; } = null!;
}
