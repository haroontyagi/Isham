﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class GatewayType
{
    public uint Id { get; set; }

    public string? Alias { get; set; }

    public string? Name { get; set; }
}
