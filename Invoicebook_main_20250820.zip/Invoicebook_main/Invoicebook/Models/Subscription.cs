﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Subscription
{
    public uint Id { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public string? ProductIds { get; set; }

    public uint? FrequencyId { get; set; }

    public string? AutoBill { get; set; }

    public string? PromoCode { get; set; }

    public double PromoDiscount { get; set; }

    public bool IsAmountDiscount { get; set; }

    public bool? AllowCancellation { get; set; }

    public bool PerSeatEnabled { get; set; }

    public uint MinSeatsLimit { get; set; }

    public uint MaxSeatsLimit { get; set; }

    public bool TrialEnabled { get; set; }

    public uint TrialDuration { get; set; }

    public bool AllowQueryOverrides { get; set; }

    public bool AllowPlanChanges { get; set; }

    public string? PlanMap { get; set; }

    public uint? RefundPeriod { get; set; }

    public string WebhookConfiguration { get; set; } = null!;

    public DateTime? DeletedAt { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public uint? CurrencyId { get; set; }

    public string? RecurringProductIds { get; set; }

    public string Name { get; set; } = null!;

    public uint? GroupId { get; set; }

    public decimal Price { get; set; }

    public decimal PromoPrice { get; set; }

    public bool RegistrationRequired { get; set; }

    public bool UseInventoryManagement { get; set; }

    public string? OptionalProductIds { get; set; }

    public string? OptionalRecurringProductIds { get; set; }

    public virtual ICollection<ClientSubscription> ClientSubscriptions { get; set; } = new List<ClientSubscription>();

    public virtual Company Company { get; set; } = null!;
}
