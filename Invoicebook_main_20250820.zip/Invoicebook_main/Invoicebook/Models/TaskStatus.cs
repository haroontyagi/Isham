﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class TaskStatus
{
    public uint Id { get; set; }

    public string? Name { get; set; }

    public uint? CompanyId { get; set; }

    public uint? UserId { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public int? StatusSortOrder { get; set; }

    public string Color { get; set; } = null!;

    public int? StatusOrder { get; set; }

    public virtual Company? Company { get; set; }

    public virtual User? User { get; set; }
}
