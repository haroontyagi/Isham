﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Bank
{
    public uint Id { get; set; }

    public string? Name { get; set; }

    public string? RemoteId { get; set; }

    public int BankLibraryId { get; set; }

    public string? Config { get; set; }

    public virtual ICollection<BankCompany> BankCompanies { get; set; } = new List<BankCompany>();
}
