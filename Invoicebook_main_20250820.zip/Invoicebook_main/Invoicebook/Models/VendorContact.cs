﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class VendorContact
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public uint VendorId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool IsPrimary { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Email { get; set; }

    public string? Phone { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public bool SendEmail { get; set; }

    public DateTime? EmailVerifiedAt { get; set; }

    public string? ConfirmationCode { get; set; }

    public bool Confirmed { get; set; }

    public DateTime? LastLogin { get; set; }

    public short? FailedLogins { get; set; }

    public string? OauthUserId { get; set; }

    public uint? OauthProviderId { get; set; }

    public string? Google2faSecret { get; set; }

    public string? AcceptedTermsVersion { get; set; }

    public string? Avatar { get; set; }

    public string? AvatarType { get; set; }

    public string? AvatarSize { get; set; }

    public string Password { get; set; } = null!;

    public string? Token { get; set; }

    public bool IsLocked { get; set; }

    public string? ContactKey { get; set; }

    public string? RememberToken { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual ICollection<PurchaseOrderInvitation> PurchaseOrderInvitations { get; set; } = new List<PurchaseOrderInvitation>();

    public virtual User User { get; set; } = null!;

    public virtual Vendor Vendor { get; set; } = null!;
}
