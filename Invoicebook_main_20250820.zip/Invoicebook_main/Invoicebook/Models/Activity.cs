﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Activity
{
    public uint Id { get; set; }

    public uint? UserId { get; set; }

    public uint CompanyId { get; set; }

    public uint? ClientId { get; set; }

    public uint? ClientContactId { get; set; }

    public uint? AccountId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? VendorId { get; set; }

    public uint? PaymentId { get; set; }

    public uint? InvoiceId { get; set; }

    public uint? CreditId { get; set; }

    public uint? InvitationId { get; set; }

    public uint? TaskId { get; set; }

    public uint? ExpenseId { get; set; }

    public uint? ActivityTypeId { get; set; }

    public string Ip { get; set; } = null!;

    public bool IsSystem { get; set; }

    public string Notes { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public uint? TokenId { get; set; }

    public uint? QuoteId { get; set; }

    public uint? SubscriptionId { get; set; }

    public uint? RecurringInvoiceId { get; set; }

    public uint? RecurringExpenseId { get; set; }

    public uint? RecurringQuoteId { get; set; }

    public uint? PurchaseOrderId { get; set; }

    public uint? VendorContactId { get; set; }

    public virtual ICollection<Backup> Backups { get; set; } = new List<Backup>();

    public virtual Company Company { get; set; } = null!;
}
