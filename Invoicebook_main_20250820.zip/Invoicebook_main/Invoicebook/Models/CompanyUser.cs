﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class CompanyUser
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint AccountId { get; set; }

    public uint UserId { get; set; }

    public string? Permissions { get; set; }

    public string? Notifications { get; set; }

    public string? Settings { get; set; }

    public string SlackWebhookUrl { get; set; } = null!;

    public bool IsOwner { get; set; }

    public bool IsAdmin { get; set; }

    public bool IsLocked { get; set; }

    public DateTime? DeletedAt { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime PermissionsUpdatedAt { get; set; }

    public string NinjaPortalUrl { get; set; } = null!;

    public string? ReactSettings { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;
}
