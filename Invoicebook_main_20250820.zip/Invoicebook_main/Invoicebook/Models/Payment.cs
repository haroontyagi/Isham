﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Payment
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint ClientId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? VendorId { get; set; }

    public uint? UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint? ClientContactId { get; set; }

    public uint? InvitationId { get; set; }

    public uint? CompanyGatewayId { get; set; }

    public uint? GatewayTypeId { get; set; }

    public uint? TypeId { get; set; }

    public uint StatusId { get; set; }

    public decimal Amount { get; set; }

    public decimal Refunded { get; set; }

    public decimal Applied { get; set; }

    public DateOnly? Date { get; set; }

    public string? TransactionReference { get; set; }

    public string? PayerId { get; set; }

    public string? Number { get; set; }

    public string? PrivateNotes { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool IsDeleted { get; set; }

    public bool IsManual { get; set; }

    public decimal ExchangeRate { get; set; }

    public uint CurrencyId { get; set; }

    public uint? ExchangeCurrencyId { get; set; }

    public string? Meta { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public ulong? TransactionId { get; set; }

    public string? IdempotencyKey { get; set; }

    public virtual Client Client { get; set; } = null!;

    public virtual ClientContact? ClientContact { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual CompanyGateway? CompanyGateway { get; set; }

    public virtual ICollection<PaymentHash> PaymentHashes { get; set; } = new List<PaymentHash>();

    public virtual ICollection<Paymentable> Paymentables { get; set; } = new List<Paymentable>();

    public virtual User? User { get; set; }
}
