﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class PaymentHash
{
    public uint Id { get; set; }

    public string Hash { get; set; } = null!;

    public decimal FeeTotal { get; set; }

    public uint? FeeInvoiceId { get; set; }

    public string Data { get; set; } = null!;

    public uint? PaymentId { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Payment? Payment { get; set; }
}
