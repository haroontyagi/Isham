﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Expense
{
    public uint Id { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public uint CompanyId { get; set; }

    public uint? VendorId { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint? InvoiceId { get; set; }

    public uint? ClientId { get; set; }

    public uint? BankId { get; set; }

    public uint? InvoiceCurrencyId { get; set; }

    public uint? CurrencyId { get; set; }

    public uint? CategoryId { get; set; }

    public uint? PaymentTypeId { get; set; }

    public uint? RecurringExpenseId { get; set; }

    public bool IsDeleted { get; set; }

    public decimal Amount { get; set; }

    public decimal ForeignAmount { get; set; }

    public decimal ExchangeRate { get; set; }

    public string? TaxName1 { get; set; }

    public decimal TaxRate1 { get; set; }

    public string? TaxName2 { get; set; }

    public decimal TaxRate2 { get; set; }

    public string? TaxName3 { get; set; }

    public decimal TaxRate3 { get; set; }

    public DateOnly? Date { get; set; }

    public DateOnly? PaymentDate { get; set; }

    public string? PrivateNotes { get; set; }

    public string? PublicNotes { get; set; }

    public string? TransactionReference { get; set; }

    public bool ShouldBeInvoiced { get; set; }

    public bool? InvoiceDocuments { get; set; }

    public ulong? TransactionId { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public string? Number { get; set; }

    public uint? ProjectId { get; set; }

    public decimal TaxAmount1 { get; set; }

    public decimal TaxAmount2 { get; set; }

    public decimal TaxAmount3 { get; set; }

    public bool UsesInclusiveTaxes { get; set; }

    public bool CalculateTaxByAmount { get; set; }

    public virtual Company Company { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
