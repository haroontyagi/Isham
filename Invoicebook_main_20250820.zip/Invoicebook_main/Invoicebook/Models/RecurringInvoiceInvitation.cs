﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class RecurringInvoiceInvitation
{
    public uint Id { get; set; }

    public uint CompanyId { get; set; }

    public uint UserId { get; set; }

    public uint ClientContactId { get; set; }

    public uint RecurringInvoiceId { get; set; }

    public string Key { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? TransactionReference { get; set; }

    public string? MessageId { get; set; }

    public string? EmailError { get; set; }

    public string? SignatureBase64 { get; set; }

    public DateTime? SignatureDate { get; set; }

    public DateTime? SentDate { get; set; }

    public DateTime? ViewedDate { get; set; }

    public DateTime? OpenedDate { get; set; }

    public string? EmailStatus { get; set; }

    public virtual ClientContact ClientContact { get; set; } = null!;

    public virtual Company Company { get; set; } = null!;

    public virtual RecurringInvoice RecurringInvoice { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
