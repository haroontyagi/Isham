﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Document
{
    public uint Id { get; set; }

    public uint UserId { get; set; }

    public uint? AssignedUserId { get; set; }

    public uint CompanyId { get; set; }

    public uint? ProjectId { get; set; }

    public uint? VendorId { get; set; }

    public string? Url { get; set; }

    public string? Preview { get; set; }

    public string? Name { get; set; }

    public string? Type { get; set; }

    public string? Disk { get; set; }

    public string? Hash { get; set; }

    public uint? Size { get; set; }

    public uint? Width { get; set; }

    public uint? Height { get; set; }

    public bool IsDefault { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public DateTime? DeletedAt { get; set; }

    public uint DocumentableId { get; set; }

    public string DocumentableType { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? IsPublic { get; set; }

    public virtual Company Company { get; set; } = null!;
}
