﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Webhook
{
    public uint Id { get; set; }

    public uint? CompanyId { get; set; }

    public uint? UserId { get; set; }

    public uint? EventId { get; set; }

    public bool IsDeleted { get; set; }

    public string TargetUrl { get; set; } = null!;

    public string Format { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? RestMethod { get; set; }

    public string? Headers { get; set; }

    public virtual Company? Company { get; set; }
}
