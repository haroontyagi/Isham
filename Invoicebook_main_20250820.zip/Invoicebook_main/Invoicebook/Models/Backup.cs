﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class Backup
{
    public uint Id { get; set; }

    public uint ActivityId { get; set; }

    public string? JsonBackup { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public decimal Amount { get; set; }

    public string? Filename { get; set; }

    public string? Disk { get; set; }

    public virtual Activity Activity { get; set; } = null!;
}
