﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Invoicebook.Models
{
    [Table("clients")]
    public partial class Client
    {   
        [Column("id")]
        public uint Id { get; set; }

        [Column("company_id")]
        public uint CompanyId { get; set; }

        [Column("user_id")]
        public uint UserId { get; set; }

        [Column("assigned_user_id")]
        public uint? AssignedUserId { get; set; }

        public string? Name { get; set; }

        public string? Website { get; set; }

        [Column("private_notes")]
        public string? PrivateNotes { get; set; }

        [Column("public_notes")]
        public string? PublicNotes { get; set; }

        [Column("client_hash")]
        public string? ClientHash { get; set; }

        public string? Logo { get; set; }

        public string? Phone { get; set; }

        public decimal Balance { get; set; }

        [Column("paid_to_date")]
        public decimal PaidToDate { get; set; }

        [Column("credit_balance")]
        public decimal CreditBalance { get; set; }

        [Column("last_login")]
        public DateTime? LastLogin { get; set; }

        [Column("industry_id")]
        public uint? IndustryId { get; set; }

        [Column("size_id")]
        public uint? SizeId { get; set; }

        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }

        [Column("postal_code")]
        public string? PostalCode { get; set; }

        [Column("country_id")]
        public uint? CountryId { get; set; }

        [Column("custom_value1")]
        public string? CustomValue1 { get; set; }

        [Column("custom_value2")]
        public string? CustomValue2 { get; set; }

        [Column("custom_value3")]
        public string? CustomValue3 { get; set; }

        [Column("custom_value4")]
        public string? CustomValue4 { get; set; }

        [Column("shipping_address1")]
        public string? ShippingAddress1 { get; set; }

        [Column("shipping_address2")]
        public string? ShippingAddress2 { get; set; }

        [Column("shipping_city")]
        public string? ShippingCity { get; set; }

        [Column("shipping_state")]
        public string? ShippingState { get; set; }

        [Column("shipping_postal_code")]
        public string? ShippingPostalCode { get; set; }

        [Column("shipping_country_id")]
        public uint? ShippingCountryId { get; set; }

        public string? Settings { get; set; }

        [Column("is_deleted")]
        public bool IsDeleted { get; set; }

        [Column("group_settings_id")]
        public uint? GroupSettingsId { get; set; }

        [Column("vat_number")]
        public string? VatNumber { get; set; }

        public string? Number { get; set; }

        [Column("created_at")]
        public DateTime? CreatedAt { get; set; }

        [Column("updated_at")]
        public DateTime? UpdatedAt { get; set; }

        [Column("deleted_at")]
        public DateTime? DeletedAt { get; set; }

        [Column("id_number")]
        public string? IdNumber { get; set; }

        [Column("payment_balance")]
        public decimal PaymentBalance { get; set; }

        [Column("routing_id")]
        public string? RoutingId { get; set; }

        [Column("tax_data")]
        public string? TaxData { get; set; }

        [Column("is_tax_exempt")]
        public bool IsTaxExempt { get; set; }

        [Column("has_valid_vat_number")]
        public bool HasValidVatNumber { get; set; }

        // Navigation properties to related entities
        public virtual ICollection<Project> Projects { get; set; } = new List<Project>();
        
        public virtual List<ClientContact> ClientContacts { get; set; } = new List<ClientContact>();

        public virtual ICollection<ClientGatewayToken> ClientGatewayTokens { get; set; } = new List<ClientGatewayToken>();

        public virtual ICollection<ClientSubscription> ClientSubscriptions { get; set; } = new List<ClientSubscription>();

        public virtual Company Company { get; set; } = null!;

        public virtual ICollection<CompanyLedger> CompanyLedgers { get; set; } = new List<CompanyLedger>();

        public virtual ICollection<Credit> Credits { get; set; } = new List<Credit>();

        public virtual Industry? Industry { get; set; }

        public virtual ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();

        public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

        public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = new List<PurchaseOrder>();

        public virtual ICollection<Quote> Quotes { get; set; } = new List<Quote>();

        public virtual ICollection<RecurringInvoice> RecurringInvoices { get; set; } = new List<RecurringInvoice>();

        public virtual ICollection<RecurringQuote> RecurringQuotes { get; set; } = new List<RecurringQuote>();

        public virtual Size? Size { get; set; }

        public virtual ICollection<SystemLog> SystemLogs { get; set; } = new List<SystemLog>();

        public virtual ICollection<Task> Tasks { get; set; } = new List<Task>();

        public virtual ICollection<TransactionEvent> TransactionEvents { get; set; } = new List<TransactionEvent>();
    }
}
