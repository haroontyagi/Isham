﻿using System;
using System.Collections.Generic;

namespace Invoicebook.Models;

public partial class User
{
    public uint Id { get; set; }

    public uint AccountId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Phone { get; set; }

    public string? Ip { get; set; }

    public string? DeviceToken { get; set; }

    public string Email { get; set; } = null!;

    public DateTime? EmailVerifiedAt { get; set; }

    public string? ConfirmationCode { get; set; }

    public int? ThemeId { get; set; }

    public short? FailedLogins { get; set; }

    public string? ReferralCode { get; set; }

    public string? OauthUserId { get; set; }

    public string? OauthUserToken { get; set; }

    public string? OauthProviderId { get; set; }

    public string? Google2faSecret { get; set; }

    public string? AcceptedTermsVersion { get; set; }

    public string? Avatar { get; set; }

    public uint? AvatarWidth { get; set; }

    public uint? AvatarHeight { get; set; }

    public uint? AvatarSize { get; set; }

    public bool IsDeleted { get; set; }

    public DateTime? LastLogin { get; set; }

    public string? Signature { get; set; }

    public string Password { get; set; } = null!;

    public string? RememberToken { get; set; }

    public string? CustomValue1 { get; set; }

    public string? CustomValue2 { get; set; }

    public string? CustomValue3 { get; set; }

    public string? CustomValue4 { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? OauthUserRefreshToken { get; set; }

    public string? LastConfirmedEmailAddress { get; set; }

    public bool HasPassword { get; set; }

    public DateTime? OauthUserTokenExpiry { get; set; }

    public string? SmsVerificationCode { get; set; }

    public bool VerifiedPhoneNumber { get; set; }

    public ulong? ShopifyUserId { get; set; }

    public virtual Account Account { get; set; } = null!;

    public virtual ICollection<BankCompany> BankCompanies { get; set; } = new List<BankCompany>();

    public virtual ICollection<BankIntegration> BankIntegrations { get; set; } = new List<BankIntegration>();

    public virtual ICollection<BankSubcompany> BankSubcompanies { get; set; } = new List<BankSubcompany>();

    public virtual ICollection<BankTransactionRule> BankTransactionRules { get; set; } = new List<BankTransactionRule>();

    public virtual ICollection<BankTransaction> BankTransactions { get; set; } = new List<BankTransaction>();

    public virtual ICollection<CompanyGateway> CompanyGateways { get; set; } = new List<CompanyGateway>();

    public virtual ICollection<CompanyToken> CompanyTokens { get; set; } = new List<CompanyToken>();

    public virtual ICollection<CreditInvitation> CreditInvitations { get; set; } = new List<CreditInvitation>();

    public virtual ICollection<Credit> Credits { get; set; } = new List<Credit>();

    public virtual ICollection<Expense> Expenses { get; set; } = new List<Expense>();

    public virtual ICollection<InvoiceInvitation> InvoiceInvitations { get; set; } = new List<InvoiceInvitation>();

    public virtual ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();

    public virtual ICollection<PaymentTerm> PaymentTerms { get; set; } = new List<PaymentTerm>();

    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    //public virtual ICollection<Product> Products { get; set; } = new List<Product>();

    public virtual ICollection<Project> Projects { get; set; } = new List<Project>();

    public virtual ICollection<PurchaseOrderInvitation> PurchaseOrderInvitations { get; set; } = new List<PurchaseOrderInvitation>();

    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = new List<PurchaseOrder>();

    public virtual ICollection<QuoteInvitation> QuoteInvitations { get; set; } = new List<QuoteInvitation>();

    public virtual ICollection<Quote> Quotes { get; set; } = new List<Quote>();

    public virtual ICollection<RecurringExpense> RecurringExpenses { get; set; } = new List<RecurringExpense>();

    public virtual ICollection<RecurringInvoiceInvitation> RecurringInvoiceInvitations { get; set; } = new List<RecurringInvoiceInvitation>();

    public virtual ICollection<RecurringInvoice> RecurringInvoices { get; set; } = new List<RecurringInvoice>();

    public virtual ICollection<RecurringQuoteInvitation> RecurringQuoteInvitations { get; set; } = new List<RecurringQuoteInvitation>();

    public virtual ICollection<RecurringQuote> RecurringQuotes { get; set; } = new List<RecurringQuote>();

    public virtual ICollection<TaskStatus> TaskStatuses { get; set; } = new List<TaskStatus>();

    public virtual ICollection<Task> Tasks { get; set; } = new List<Task>();

    public virtual ICollection<TaxRate> TaxRates { get; set; } = new List<TaxRate>();

    public virtual ICollection<VendorContact> VendorContacts { get; set; } = new List<VendorContact>();

    public virtual ICollection<Vendor> Vendors { get; set; } = new List<Vendor>();
}
