﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Invoicebook.Models;
using Invoicebook.Data;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicebook.Controllers
{
    public class ClientController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClientController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Client
        public async Task<IActionResult> Index()
        {
            var clients = await _context.Clients
                .Where(c => !c.IsDeleted)
                .OrderBy(c => c.Number)
                .ToListAsync();
            
            return View(clients);
        }

        // GET: Client/GetAll - For DataTables AJAX
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var clients = _context.Clients
    .Where(c => !c.IsDeleted)
    .Select(c => new {
                    id = c.Id,
                    name = c.Name,
                    number = c.Number,
                    balance = c.Balance,
                    paidToDate = c.PaidToDate,
                    contactName = c.ContactFirstName + " " + c.ContactLastName,
                    contactEmail = c.ContactEmail,
                    contactPhone = c.ContactPhone,
                    billingStreet = c.BillingStreet,
                    billingCity = c.BillingCity,
                    billingStateProvince = c.BillingStateProvince,
                    billingPostalCode = c.BillingPostalCode,
                    billingCountry = c.BillingCountry,
                    createdAt = c.CreatedAt.HasValue ? c.CreatedAt.Value.ToString("yyyy-MM-dd HH:mm:ss") : ""
                }).ToList();
            return Json(clients);

            }
            catch (Exception ex)
            {
                return Json(new { error = ex.Message });
            }
        }

        // GET: Client/Create
        [HttpGet]
        public IActionResult Create()
        {
            var client = new Client
            {
                CompanyId = 1,
                UserId = 1,
                Balance = 0m,
                PaidToDate = 0m,
                CreditBalance = 0m,
                PaymentBalance = 0m,
                TaskRate = 0m,
                IsDeleted = false,
                IsTaxExempt = false,
                HasValidVatNumber = false,
                SendReminders = false,
                JoinedDate = DateTime.Now,
                CreatedAt = DateTime.UtcNow
            };

            return PartialView("CreateClient", client);
        }

        // POST: Client/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Client model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return PartialView("CreateClient", model);
                }

                // Set default values
                model.CompanyId = model.CompanyId == 0 ? 1 : model.CompanyId;
                model.UserId = model.UserId == 0 ? 1 : model.UserId;
                model.Balance = model.Balance ?? 0m;
                model.PaidToDate = model.PaidToDate ?? 0m;
                model.CreditBalance = model.CreditBalance ?? 0m;
                model.PaymentBalance = model.PaymentBalance ?? 0m;
                model.TaskRate = model.TaskRate ?? 0m;
                model.IsDeleted = false;
                model.IsTaxExempt = model.IsTaxExempt;
                model.HasValidVatNumber = model.HasValidVatNumber;
                model.SendReminders = model.SendReminders;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                // Generate client number if not provided
                if (string.IsNullOrEmpty(model.Number))
                {
                    var lastClient = await _context.Clients
                        .OrderByDescending(c => c.Id)
                        .FirstOrDefaultAsync();
                    
                    var nextNumber = (lastClient?.Id ?? 0) + 1;
                    model.Number = $"CL{nextNumber:D4}";
                }

                _context.Clients.Add(model);
                await _context.SaveChangesAsync();

                return Json(new { success = true, RedirectUrl = Url.Action("Index") });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while creating the client: " + ex.Message);
                return PartialView("CreateClient", model);
            }
        }

        // GET: Client/Edit/5
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var client = await _context.Clients
                    .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

                if (client == null)
                {
                    return NotFound();
                }

                return View(client);
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Error loading client: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Client/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Client model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            try
            {
                if (!ModelState.IsValid)
                {
                    return View(model);
                }

                var existingClient = await _context.Clients
                    .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

                if (existingClient == null)
                {
                    return NotFound();
                }

                // Update properties
                existingClient.Number = model.Number ?? existingClient.Number;
                existingClient.Name = model.Name ?? existingClient.Name;
                existingClient.Email = model.Email ?? existingClient.Email;
                existingClient.Phone = model.Phone ?? existingClient.Phone;
                existingClient.Website = model.Website ?? existingClient.Website;
                existingClient.JoinedDate = model.JoinedDate ?? existingClient.JoinedDate;

                // Contact Info
                existingClient.ContactFirstName = model.ContactFirstName ?? existingClient.ContactFirstName;
                existingClient.ContactLastName = model.ContactLastName ?? existingClient.ContactLastName;
                existingClient.ContactEmail = model.ContactEmail ?? existingClient.ContactEmail;
                existingClient.ContactPhone = model.ContactPhone ?? existingClient.ContactPhone;

                // Financial Info
                existingClient.Balance = model.Balance ?? existingClient.Balance ?? 0m;
                existingClient.PaidToDate = model.PaidToDate ?? existingClient.PaidToDate ?? 0m;
                existingClient.Currency = model.Currency ?? existingClient.Currency;
                existingClient.InvoicePaymentTerms = model.InvoicePaymentTerms ?? existingClient.InvoicePaymentTerms;
                existingClient.QuoteValidUntil = model.QuoteValidUntil ?? existingClient.QuoteValidUntil;
                existingClient.TaskRate = model.TaskRate ?? existingClient.TaskRate ?? 0m;

                // Billing Address
                existingClient.BillingAptSuite = model.BillingAptSuite ?? existingClient.BillingAptSuite;
                existingClient.BillingStreet = model.BillingStreet ?? existingClient.BillingStreet;
                existingClient.BillingCity = model.BillingCity ?? existingClient.BillingCity;
                existingClient.BillingStateProvince = model.BillingStateProvince ?? existingClient.BillingStateProvince;
                existingClient.BillingPostalCode = model.BillingPostalCode ?? existingClient.BillingPostalCode;
                existingClient.BillingCountry = model.BillingCountry ?? existingClient.BillingCountry;

                // Shipping Address
                existingClient.ShippingAptSuite = model.ShippingAptSuite ?? existingClient.ShippingAptSuite;
                existingClient.ShippingStreet = model.ShippingStreet ?? existingClient.ShippingStreet;
                existingClient.ShippingCity = model.ShippingCity ?? existingClient.ShippingCity;
                existingClient.ShippingStateProvince = model.ShippingStateProvince ?? existingClient.ShippingStateProvince;
                existingClient.ShippingPostalCode = model.ShippingPostalCode ?? existingClient.ShippingPostalCode;
                existingClient.ShippingCountry = model.ShippingCountry ?? existingClient.ShippingCountry;

                // Extra Info
                existingClient.IdNumber = model.IdNumber ?? existingClient.IdNumber;
                existingClient.VatNumber = model.VatNumber ?? existingClient.VatNumber;
                existingClient.Size = model.Size ?? existingClient.Size;
                existingClient.Industry = model.Industry ?? existingClient.Industry;
                existingClient.PublicNotes = model.PublicNotes ?? existingClient.PublicNotes;
                existingClient.PrivateNotes = model.PrivateNotes ?? existingClient.PrivateNotes;

                // Boolean fields
                existingClient.IsTaxExempt = model.IsTaxExempt;
                existingClient.HasValidVatNumber = model.HasValidVatNumber;
                existingClient.SendReminders = model.SendReminders;

                existingClient.UpdatedAt = DateTime.UtcNow;

                _context.Update(existingClient);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Client updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await ClientExists(model.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while updating the client: " + ex.Message);
                return View(model);
            }
        }

        // POST: Client/Delete/5
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var client = await _context.Clients
                    .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

                if (client == null)
                {
                    return Json(new { success = false, message = "Client not found." });
                }

                // Soft delete
                client.IsDeleted = true;
                client.DeletedAt = DateTime.UtcNow;
                client.UpdatedAt = DateTime.UtcNow;

                _context.Update(client);
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Client deleted successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error deleting client: " + ex.Message });
            }
        }

        // GET: Client/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var client = await _context.Clients
                    .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

                if (client == null)
                {
                    return NotFound();
                }

                return View(client);
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Error loading client details: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        private async Task<bool> ClientExists(int id)
        {
            return await _context.Clients.AnyAsync(e => e.Id == id && !e.IsDeleted);
        }
    }
}
