using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Invoicebook.Models
{
    [Table("clients")]
    public class Client
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("company_id")]
        public int CompanyId { get; set; } = 1;

        [Column("user_id")]
        public int UserId { get; set; } = 1;

        [Column("assigned_user_id")]
        public int? AssignedUserId { get; set; }

        [Column("name")]
        [StringLength(255)]
        public string? Name { get; set; }

        [Column("website")]
        [StringLength(255)]
        public string? Website { get; set; }

        [Column("private_notes")]
        public string? PrivateNotes { get; set; }

        [Column("public_notes")]
        public string? PublicNotes { get; set; }

        [Column("client_hash")]
        [StringLength(255)]
        public string? ClientHash { get; set; }

        [Column("logo")]
        [StringLength(255)]
        public string? Logo { get; set; }

        [Column("phone")]
        [StringLength(50)]
        public string? Phone { get; set; }

        [Column("balance", TypeName = "decimal(18,2)")]
        public decimal? Balance { get; set; } = 0m;

        [Column("paid_to_date", TypeName = "decimal(18,2)")]
        public decimal? PaidToDate { get; set; } = 0m;

        [Column("credit_balance", TypeName = "decimal(18,2)")]
        public decimal? CreditBalance { get; set; } = 0m;

        [Column("last_login")]
        public DateTime? LastLogin { get; set; }

        [Column("industry_id")]
        public int? IndustryId { get; set; }

        [Column("size_id")]
        public int? SizeId { get; set; }

        [Column("address1")]
        [StringLength(255)]
        public string? Address1 { get; set; }

        [Column("address2")]
        [StringLength(255)]
        public string? Address2 { get; set; }

        [Column("city")]
        [StringLength(100)]
        public string? City { get; set; }

        [Column("state")]
        [StringLength(100)]
        public string? State { get; set; }

        [Column("postal_code")]
        [StringLength(20)]
        public string? PostalCode { get; set; }

        [Column("country_id")]
        public int? CountryId { get; set; }

        // Billing Address
        [Column("billingaptsuite")]
        [StringLength(100)]
        public string? BillingAptSuite { get; set; }

        [Column("billingstreet")]
        [StringLength(255)]
        public string? BillingStreet { get; set; }

        [Column("billingcity")]
        [StringLength(100)]
        public string? BillingCity { get; set; }

        [Column("billingstateprovince")]
        [StringLength(100)]
        public string? BillingStateProvince { get; set; }

        [Column("billingpostalcode")]
        [StringLength(20)]
        public string? BillingPostalCode { get; set; }

        [Column("billingcountry")]
        [StringLength(100)]
        public string? BillingCountry { get; set; }

        // Shipping Address
        [Column("shippingaptsuite")]
        [StringLength(100)]
        public string? ShippingAptSuite { get; set; }

        [Column("shippingstreet")]
        [StringLength(255)]
        public string? ShippingStreet { get; set; }

        [Column("shippingcity")]
        [StringLength(100)]
        public string? ShippingCity { get; set; }

        [Column("shippingstateprovince")]
        [StringLength(100)]
        public string? ShippingStateProvince { get; set; }

        [Column("shippingpostalcode")]
        [StringLength(20)]
        public string? ShippingPostalCode { get; set; }

        [Column("shippingcountry")]
        [StringLength(100)]
        public string? ShippingCountry { get; set; }

        [Column("settings")]
        public string? Settings { get; set; }

        [Column("is_deleted")]
        public bool IsDeleted { get; set; } 

        [Column("vat_number")]
        [StringLength(50)]
        public string? VatNumber { get; set; }

        [Column("number")]
        [StringLength(50)]
        public string? Number { get; set; }

        [Column("created_at")]
        public DateTime? CreatedAt { get; set; }

        [Column("updated_at")]
        public DateTime? UpdatedAt { get; set; }

        [Column("deleted_at")]
        public DateTime? DeletedAt { get; set; }

        [Column("id_number")]
        [StringLength(50)]
        public string? IdNumber { get; set; }

        [Column("payment_balance", TypeName = "decimal(18,2)")]
        public decimal? PaymentBalance { get; set; } = 0m;

        [Column("routing_id")]
        [StringLength(50)]
        public string? RoutingId { get; set; }

        [Column("tax_data")]
        public string? TaxData { get; set; }

        [Column("is_tax_exempt")]
        public bool IsTaxExempt { get; set; }

        [Column("has_valid_vat_number")]
        public bool HasValidVatNumber { get; set; }

        [Column("email")]
        [StringLength(255)]
        [EmailAddress]
        public string? Email { get; set; }

        [Column("joineddate")]
        public DateTime? JoinedDate { get; set; }

        [Column("currency")]
        [StringLength(10)]
        public string? Currency { get; set; }

        [Column("language")]
        [StringLength(10)]
        public string? Language { get; set; }

        [Column("invoicepaymentterms")]
        [StringLength(100)]
        public string? InvoicePaymentTerms { get; set; }

        [Column("quotevaliduntil")]
        [StringLength(100)]
        public string? QuoteValidUntil { get; set; }

        [Column("sendreminders")]
        public bool? SendReminders { get; set; }

        [Column("size")]
        [StringLength(50)]
        public string? Size { get; set; }

        [Column("industry")]
        [StringLength(100)]
        public string? Industry { get; set; }
        [Column("taskrate", TypeName = "decimal(18,2)")]
        public decimal? TaskRate { get; set; } = 0m;
        [Column("contactfirstname")]
        [StringLength(100)]
        public string? ContactFirstName { get; set; }

        [Column("contactlastname")]
        [StringLength(100)]
        public string? ContactLastName { get; set; }

        [Column("contactemail")]
        [StringLength(255)]
        [EmailAddress]
        public string? ContactEmail { get; set; }

        [Column("contactphone")]
        [StringLength(50)]
        public string? ContactPhone { get; set; }

        // Computed property for display
        [NotMapped]
        public string ContactName
        {
            get
            {
                var name = $"{ContactFirstName} {ContactLastName}".Trim();
                return string.IsNullOrWhiteSpace(name) ? "N/A" : name;
            }
        }

        [NotMapped]
        public string FullBillingAddress
        {
            get
            {
                var parts = new[] { BillingStreet, BillingCity, BillingStateProvince, BillingPostalCode, BillingCountry }
                    .Where(p => !string.IsNullOrWhiteSpace(p));
                return string.Join(", ", parts);
            }
        }

        [NotMapped]
        public string FullShippingAddress
        {
            get
            {
                var parts = new[] { ShippingStreet, ShippingCity, ShippingStateProvince, ShippingPostalCode, ShippingCountry }
                    .Where(p => !string.IsNullOrWhiteSpace(p));
                return string.Join(", ", parts);
            }
        }
    }
}
